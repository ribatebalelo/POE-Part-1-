package registrationandlogin;

import java.sql.Connection;
import org.junit.Test;
import static org.junit.Assert.*;

public class ConnIT {
    
    @Test
    public void testConnect() {
        System.out.println("connect");
        Connection result = Conn.connect();
        assertNotNull(result);
        try {
            assertFalse(result.isClosed());
            result.close();
        } catch (Exception e) {
            fail("Exception occurred: " + e.getMessage());
        }
    }
}
