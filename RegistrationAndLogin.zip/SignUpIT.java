package registrationandlogin;

import org.junit.Test;
import static org.junit.Assert.*;

public class SignUpIT {
    
    @Test
    public void testUsernameValidation() {
        SignUp instance = new SignUp();
        
        // Test valid username
        assertTrue(instance.validateUsername("user_"));
        
        // Test invalid usernames
        assertFalse(instance.validateUsername("")); // empty
        assertFalse(instance.validateUsername("username")); // no underscore
        assertFalse(instance.validateUsername("user__name")); // multiple underscores
        assertFalse(instance.validateUsername("verylongusername")); // too long
    }
    
    @Test
    public void testPasswordValidation() {
        SignUp instance = new SignUp();
        
        // Test valid password
        assertTrue(instance.validatePassword("Passw0rd@"));
        
        // Test invalid passwords
        assertFalse(instance.validatePassword("short")); // too short
        assertFalse(instance.validatePassword("nouppercase1@")); // no uppercase
        assertFalse(instance.validatePassword("NOLOWERCASE1@")); // no lowercase
        assertFalse(instance.validatePassword("NoSpecial1")); // no special char
        assertFalse(instance.validatePassword("NoNumber@")); // no number
    }
    
    @Test
    public void testPasswordMatch() {
        SignUp instance = new SignUp();
        
        assertTrue(instance.validatePasswordMatch("password", "password"));
        assertFalse(instance.validatePasswordMatch("password1", "password2"));
    }
    
    // Helper methods to make validation accessible (you'll need to add these to your SignUp class)
    private boolean validateUsername(String username) {
        if(username.isEmpty()) return false;
        if(username.length() > 5) return false;
        if(username.chars().filter(ch -> ch == '_').count() != 1) return false;
        return true;
    }
    
    private boolean validatePassword(String password) {
        if(password.length() < 8 || password.length() >= 16) return false;
        if(!password.matches(".*[A-Z].*")) return false;
        if(!password.matches(".*\\d.*")) return false;
        if(!password.matches(".*[@#$%^&*()_+=|<>{}\\[\\]~-].*")) return false;
        return true;
    }
    
    private boolean validatePasswordMatch(String password1, String password2) {
        return password1.equals(password2);
    }
}
