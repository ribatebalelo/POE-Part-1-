package registrationandlogin;

import org.junit.Test;
import static org.junit.Assert.*;

public class loginIT {
    
    @Test
    public void testEmptyFieldValidation() {
        login instance = new login();
        
        // Test empty username, password, and phone number
        assertFalse(instance.validateInputs("", "password123", "0123456789"));
        assertFalse(instance.validateInputs("username", "", "0123456789"));
        assertFalse(instance.validateInputs("username", "password123", ""));
        assertFalse(instance.validateInputs("", "", ""));
    }
    
    @Test
    public void testPhoneNumberValidation() {
        login instance = new login();
        
        // Test valid phone number format
        assertTrue(instance.validatePhoneNumber("0123456789"));
        
        // Test invalid phone number formats
        assertFalse(instance.validatePhoneNumber("1234567890")); // doesn't start with 0
        assertFalse(instance.validatePhoneNumber("012345678")); // too short
        assertFalse(instance.validatePhoneNumber("01234567890")); // too long
        assertFalse(instance.validatePhoneNumber("0123abc789")); // contains letters
    }
    
    // Helper method to make validateInputs accessible (you'll need to add this to your login class)
    private boolean validateInputs(String username, String password, String phoneNumber) {
        if(username.isEmpty() || password.isEmpty() || phoneNumber.isEmpty()) {
            return false;
        }
        return true;
    }
    
    // Helper method to make validatePhoneNumber accessible (you'll need to add this to your login class)
    private boolean validatePhoneNumber(String phoneNumber) {
        return phoneNumber.matches("^0\\d{9}$");
    }
}
