/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4Suite.java to edit this template
 */
package registrationandlogin;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

/**
 *
 * @author RC_Student_lab
 */
@RunWith(Suite.class)
@Suite.SuiteClasses({registrationandlogin.loginIT.class, RegistrationAndLoginTest.class, ConnIT.class, HomePageIT.class, SignUpTestIT.class, SignUpIT.class})
public class RegistrationandloginITSuite {

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }
    
}
